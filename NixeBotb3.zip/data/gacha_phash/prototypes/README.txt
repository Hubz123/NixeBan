Taruh beberapa screenshot hasil gacha/banner result di folder ini.
Format: PNG/JPG/WEBP. 2–3 contoh per game sudah cukup.
