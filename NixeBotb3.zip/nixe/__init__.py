# make nixe a package
