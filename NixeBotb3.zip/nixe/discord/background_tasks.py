from __future__ import annotations
def run_background_tasks(bot):
    return None
