# smoke-safe init
