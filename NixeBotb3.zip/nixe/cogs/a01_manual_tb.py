from __future__ import annotations
async def setup(bot): return
def setup_legacy(bot): return
