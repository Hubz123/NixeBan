# -*- coding: utf-8 -*-
# Hardcoded IDs (module-only) so any import path will yield non-zero values.
LOG_BOTPHISHING    =   1431178130155896882
THREAD_NIXE_DB     = 1431192568221270108
THREAD_IMAGEPHISH  = 1409949797313679492
# alias for compatibility with scripts using the typo
THREAD_IMAGEPHISING = THREAD_IMAGEPHISH
TESTBAN_CHANNEL_ID = 936690788946030613
BAN_BRAND_NAME     = "external"
